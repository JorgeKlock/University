#include "aux.h"
#include "cono.h"

Cono::Cono         (const int num_vert_perfil, 
                    const int num_instancias_perf, 
                    const float altura, 
                    const float radio)
{
   std::vector<Tupla3f> perfil;
   float desplazamiento_superior = altura/(num_vert_perfil-1);
   float desplazamiento_lateral = radio/(num_vert_perfil-1);
   
   for(int i=0; i<num_vert_perfil; i++)
   {
      perfil.push_back({i*desplazamiento_lateral, altura-(i*desplazamiento_superior), 0});
   }
   this->crearMalla(perfil, num_instancias_perf, true, true);
}
