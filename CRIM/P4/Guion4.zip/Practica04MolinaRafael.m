%% Practica04MolinaRafael
% Cambia el nombre del gui�n a Practica04tuapellidonombre

% Incluye aqu� tu nombre y apellidos
% Tiempo: Incluye aqu� el tiempo dedicado a realizar el guion

%% Paso 1. Entregar discusi�n en pdf

% Al observar las curvas anteriores surge una pregunta, �es posible que 
% las l�neas roja y verde de la segunda figura y la roja de la primera �
% no sean c�ncavas?. �Si es posible, qu� indican?. Escribe y justifica 
% tu respuesta en el paso 1 de Practica04ApellidoNombre.pdf.

%% Paso 2. Escribir c�digo aqu�

% En el paso 2 de Practica04ApellidoNombre.m escribe c�digo Matlab para:
% �	leer la imagen sin comprimir bird.pgm, 
% �	salvar la imagen bird.pgm  usando JPEG variando el factor de calidad 
%   desde 5 a 100 en pasos de 5 (ver manual de imwrite). Llama a las im�genes
%   comprimidas birdx.jpeg con x=5,10,15,20,� 100. 
% �	mostrar en una ventana las 20 im�genes obtenidas.


%% Paso 3. Respuesta en pdf

% Incluye en el paso 3 de Practica04ApellidoNombre.pdf la ventana que 
% contiene las 20 im�genes. Exam�nalas con detenimiento y comenta 
% brevemente su calidad.

%% Paso 4. Incluye c�digo en Matlab

%En el paso 4 de Practica04ApellidoNombre.m escribe c�digo Matlab para:

%1)	calcular el espacio que ocupa en bits cada 8 bits del fichero original 
%   para cada fichero comprimido birdx.jpeg con x? {5,10,15,�,100}. 
%   Es decir, calcula la tasa.
%2) calcular la distorsi�n como error cuadr�tico medio entre las im�genes 
%   en bird.pgm y birdx.jpeg, x=5, 10, 15, 20,�,100.
%3) representar los puntos tasa/distorsi�n obtenidos.

%Te ser� de utilidad la funci�n dir.


%% Paso 5. Incluye respuesta en pdf

%   Completa en el paso 5 de Practica04ApellidoNombre.pdf la siguiente tabla e
%   incluye la curva tasa/distorsi�n que has obtenido en el
%   paso anterior.


%% Paso 6. Incluye c�digo Matlab

% En el paso 6 de Practica04ApellidoNombre.m escribe c�digo Matlab para:
%1) salvar la imagen bird.pgm  usando JPEG2000 variando el factor de 
%   compresi�n �CompressionRatio� en x? {40, 38, 36, 34, �, 6, 4 ,2}. 
%   Llama a las im�genes comprimidas birdx.jp2 con x? {40, 38, 36, 34, �, 6, 4 ,2}.
%2) mostrar en una ventana las 20 im�genes obtenidas.

 
%% Paso 7. Incluye respuesta en fichero pdf

% Incluye en el paso 7 de Practica04ApellidoNombre.pdf la ventana que 
% contiene las 20 im�genes. Exam�nalas con detenimiento y comenta 
% brevemente su calidad.

%% Paso 8. Incluye c�digo Matlab

% En el paso 8 de Practica04ApellidoNombre.m escribe c�digo Matlab para:

%1) calcular el espacio que ocupa en bits cada 8 bits del fichero original 
%   para cada fichero comprimido birdx.jp2 con x? {40, 38, 36, 34, �, 6, 4 ,2}. 
%   Es decir, calcula la tasa.
%2) calcular la distorsi�n como error cuadr�tico medio entre las im�genes en 
%   bird.pgm y birdx.jp2, x? {40, 38, 36, 34, �, 6, 4 ,2}.
%3) representar los puntos tasa/distorsi�n obtenidos.

% Te ser� de utilidad la funci�n dir.

%% Paso 9. Incluye respuesta en pdf

%   Completa en el paso 9 de Practica04ApellidoNombre.pdf la siguiente tabla 
%   e incluye la curva tasa/distorsi�n que has obtenido en el paso
%   anterior.

%% Paso 10. Incluye respuesta en pdf

%   En el paso 10 de Practica04ApellidoNombre.pdf, representa en un mismo 
%   gr�fico las dos curvas obtenidas en los pasos 5 y 9 y anal�zalas. Completa 
%   la tabla adjunta


%% Paso 11. Incluye tus respuestas en pdf

% En el paso 11 de Practica04ApellidoNombre.pdf:
%�	muestra las figuras bird10.jpeg y bird34.jp2,
%�	incluye sus tasas y distorsiones,
%�	comenta y compara la calidad de ambas im�genes.

%% Paso 12

% En el paso 12 de Practica04ApellidoNombre.pdf:
%�	muestra las figuras bird90.jpeg y bird6.jp2,
%�	incluye sus tasas y distorsiones,
%�	comenta y compara la calidad de ambas im�genes.








