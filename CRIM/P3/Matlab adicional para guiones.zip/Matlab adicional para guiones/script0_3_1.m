%{
SCRIPT:         script0_3_1.m
SUPPLEMENT TO:  Tutorial 00.3
DESCRIPTION:    Introduction to scripts in MATLAB
%}

%   Copyright 2011 O. Marques
%   Practical Image and Video Processing Using MATLAB, Wiley-IEEE, 2011.

%Example of a comment line

X = ones(3,3)  %Comments can precede code on the same line
Y = 10;
Z = X * Y