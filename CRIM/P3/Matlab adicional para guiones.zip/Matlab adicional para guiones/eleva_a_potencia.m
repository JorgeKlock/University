function z = eleva_a_potencia(val,exp)
%ELEVA_A_POTENCIA calcula la potencia de un n�mero
%   z = eleva_a_potencia(val,exp) eleva val a exp
%   y lo almacena en z.

%   la primera l�nea se llama H1 y debe aparecer justo debajo de la funcion
%   Luego viene el texto de Help (help eleva_a_potencia)
%   Despu�s la funci�n
%   Comentarios van precedidos por %
%   $Revision: 1.0 Date: 22/04/2013

%realiza los c�lculos
z = val ^ exp; 
