function JQ1 = bFrameCal(ImB,bufferImageIP,array,mbSize,p,motionVector);
JQ1=compensatedFrameB(ImB,bufferImageIP,mbSize,p,array,motionVector);