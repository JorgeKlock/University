function result = deZigZag(data)
 
result=[ data(1,1) data(1,2) data(1,6) data(1,7) data(1,15) data(1,16) data(1,28) data(1,29)
data(1,3) data(1,5) data(1,8) data(1,14) data(1,17) data(1,27) data(1,30) data(1,43)
data(1,4) data(1,9) data(1,13) data(1,18) data(1,26) data(1,31) data(1,42) data(1,44)
data(1,10) data(1,12) data(1,19) data(1,25) data(1,32) data(1,41) data(1,45) data(1,54)
data(1,11) data(1,20) data(1,24) data(1,33) data(1,40) data(1,46) data(1,53) data(1,55)
data(1,21) data(1,23) data(1,34) data(1,39) data(1,47) data(1,52) data(1,56) data(1,61)
data(1,22) data(1,35) data(1,38) data(1,48) data(1,51) data(1,57) data(1,60) data(1,62)
data(1,36) data(1,37) data(1,49) data(1,50) data(1,58) data(1,59) data(1,63) data(1,64) ];


 