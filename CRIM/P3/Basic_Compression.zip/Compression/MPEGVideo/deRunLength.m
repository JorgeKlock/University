function m=deRunLength(c,array,MatAC,MatDC)
m = inverseDCT(c,array);