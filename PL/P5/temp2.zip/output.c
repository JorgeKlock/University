#include <stdio.h>
#include<stdbool.h>
int e1 = 1 ; 
int e2 = 2 ; 
int e3,e4,e5 = 6 ; 
double pReal = 0.2 ; 
double r1,r2,r3 = 2 ; 
bool bool1,bool2 = true ; 

int main(int argc,char* argv[]){
{
bool tmp2;
bool tmp1;
bool tmp0;
tmp0 = e1>e2;
tmp1 = tmp0&&e3;
tmp2 = tmp1>e2;
bool1=tmp2;
}
{
int tmp8;
int tmp7;
int tmp6;
int tmp5;
int tmp4;
int tmp3;
tmp3 = e1+e2;
tmp4 = tmp3-e5;
tmp5 = tmp4/e1;
tmp6 = tmp5-e4;
tmp7 = tmp6+e3;
tmp8 = tmp7*e2;
pReal=tmp8;
}
{
etiqueta1: 
 { 
 bool tmp9;
tmp9 = e5>e1;
if(!tmp9) goto etiqueta0 ; 
{
{
int tmp10;
tmp10 = e5-1;
e5=tmp10;

}
}

 goto etiqueta1; 
 } 
 } 
  etiqueta0: 
{
bool tmp11;
tmp11 = bool1&bool2;
if(!tmp11) goto etiqueta2 ; 
{
{
int tmp12;
tmp12 = 1+1;
e1=tmp12;
}
}
 goto etiqueta3;
 etiqueta2: 
 {} 
 } 
etiqueta3: 
{
bool tmp15;
bool tmp14;
bool tmp13;
tmp13 = e1>e2;
tmp14 = tmp13&&e3;
tmp15 = tmp14>e2;
bool2=tmp15;
}
{
bool tmp16;
tmp16 = e1>e2;
if(!tmp16) goto etiqueta4 ; 
{
{
double tmp17;
tmp17 = 0.2+0.1;
r1=tmp17;
}
}
 goto etiqueta5;
 etiqueta4: 
 {
{
double tmp18;
tmp18 = 0.3+0.2;
r2=tmp18;
}
}
 
 } 
etiqueta5: 
return e4;}

