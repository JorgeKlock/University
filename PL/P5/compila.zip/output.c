#include <stdio.h>
#include<stdbool.h>
int e1 = 1 ; 
int e2 = 2 ; 
int e7 = 4 ; 
int e3,e4,e5 = 6 ; 
double pReal = 0.2 ; 
double r1,r2,r3 = 2 ; 
bool bool1,bool2 = true ; 

int main(int argc,char* argv[]){
{
bool tmp2;
bool tmp1;
bool tmp0;
tmp0 = e1>e2;
tmp1 = tmp0&&e3;
tmp2 = tmp1>e2;
bool1=tmp2;
}
{
int tmp8;
int tmp7;
int tmp6;
int tmp5;
int tmp4;
int tmp3;
tmp3 = e1+e2;
tmp4 = tmp3-e5;
tmp5 = tmp4/e1;
tmp6 = tmp5-e4;
tmp7 = tmp6+e3;
tmp8 = tmp7*e2;
pReal=tmp8;
}
scanf("%d ",&e2);
printf("Hoooooooooola %d ",e1);
{
int tmp14;
int tmp13;
int tmp12;
int tmp11;
int tmp10;
int tmp9;
tmp9 = e1+e2;
tmp10 = tmp9-e5;
tmp11 = tmp10/e1;
tmp12 = tmp11-e4;
tmp13 = tmp12+e3;
tmp14 = tmp13*e2;
pReal=tmp14;
}
{
etiqueta1: 
 { 
 bool tmp15;
tmp15 = e5>e1;
if(!tmp15) goto etiqueta0 ; 
{
{
int tmp16;
tmp16 = e5-1;
e5=tmp16;
}
}

 goto etiqueta1; 
 } 
 } 
  etiqueta0: 
{
bool tmp17;
tmp17 = bool1&bool2;
if(!tmp17) goto etiqueta2 ; 
{
{
int tmp18;
tmp18 = 1+1;
e1=tmp18;
}
}
 goto etiqueta3;
 etiqueta2: 
 {} 
 } 
etiqueta3: 
{
bool tmp21;
bool tmp20;
bool tmp19;
tmp19 = e1>e2;
tmp20 = tmp19&&e3;
tmp21 = tmp20>e2;
bool2=tmp21;
}
{
bool tmp22;
tmp22 = e1>e2;
if(!tmp22) goto etiqueta4 ; 
{
{
double tmp23;
tmp23 = 0.2+0.1;
r1=tmp23;
}
}
 goto etiqueta5;
 etiqueta4: 
 {
{
double tmp24;
tmp24 = 0.3+0.2;
r2=tmp24;
}
}
 
 } 
etiqueta5: 
return e4;}

