Principal {
var
varend
a = 980
}